// const primary = '#cbcbcb';
// const secondary = '#0852EC';
// const label = '#DF7457';
// const background = '#E8E8E8';

// const bluePage = '#61AEEB';
// const lightBlue = '#EAF5FC';

// const red = '#ED6145';
// const offline = '#DD5E56';

// const green = '#6DB47D';
// const lightGreen = '#F9F9F9';
// const textGreen = '#74C1B8';

// const online = '#CFDA5F';

// const lightGray = '#FAFAFA';

// const white = '#ffffff';
// const black = '#000000';

// // texts
// const titleText = {
//   fontSize: 32,
// };

// const secondTitleText = {
//   fontSize: 21,
//   fontWeight: 500,
// };

// const headlineText = {
//   fontSize: 16,
//   fontWeight: 500,
// };

// const subheaderText = {
//   fontSize: 14,
// };

// const bodyText = {
//   fontSize: 13,
// };

// const footnoteText = {
//   fontSize: 12,
// };

// const captionText = {
//   fontSize: 10,
// };

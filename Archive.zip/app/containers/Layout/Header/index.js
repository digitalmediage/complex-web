// /* eslint-disable import/named */
// /*
//  * Header
//  *
//  */

// import React from 'react';
// import styles from './styles.css';

// export default function SignIn() {
//   return (
//     <div className={styles.header}>
//       <div className={styles.leftBox}>
//         <div />
//         <p>En</p>
//       </div>
//       <ul className={styles.centerBox}>
//         <li>
//           <a>Home</a>
//         </li>
//         <li>
//           <a>Complexes</a>
//         </li>
//         <li>
//           <a>Properties</a>
//         </li>
//         <li>
//           <a>Manager</a>
//         </li>
//         <li>
//           <a>News</a>
//         </li>
//         <li>
//           <a>Messages</a>
//         </li>
//       </ul>
//       <div className={styles.rightBox}>
//         <div className={styles.alert} />
//         <div className={styles.profile} />
//       </div>
//     </div>
//   );
// }

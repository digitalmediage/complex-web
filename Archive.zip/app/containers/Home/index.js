/* eslint-disable import/named */
/*
 * Home
 *
 */

import React from 'react';
import { Helmet } from 'react-helmet';
import styles from './styles.css';

export default function SignIn() {
  return (
    <article>
      <Helmet>
        <title>Home Page</title>
        <meta name="description" content="this is Home page" />
      </Helmet>
      <div className={styles.header}>
        <div className={styles.leftBox}>
          <div />
          <p>En</p>
        </div>
        <ul className={styles.centerBox}>
          <li>
            <a>Home</a>
          </li>
          <li>
            <a>Complexes</a>
          </li>
          <li>
            <a>Properties</a>
          </li>
          <li>
            <a>Manager</a>
          </li>
          <li>
            <a>News</a>
          </li>
          <li>
            <a>Messages</a>
          </li>
        </ul>
        <div className={styles.rightBox}>
          <div className={styles.alert} />
          <div className={styles.profile} />
        </div>
      </div>
      <div className={styles.container}>
        <div className={styles.grayBox}>
          <section className={styles.informationBox}>
            <div className={styles.news}>
              <div className={styles.label}>News</div>
              <div className={styles.date}>
                <ul className={styles.days}>
                  <li>Sun</li>
                  <li>Mon</li>
                  <li>Tue</li>
                  <li>Wed</li>
                  <li>Thu</li>
                  <li>Fri</li>
                  <li>Sat</li>
                </ul>
                <ul className={styles.numbers}>
                  <li>
                    <a>1</a>
                  </li>
                  <li>
                    <a>2</a>
                  </li>
                  <li className={styles.active}>
                    <a>3</a>
                  </li>
                  <li>
                    <a>4</a>
                  </li>
                  <li>
                    <a>5</a>
                  </li>
                  <li>
                    <a>6</a>
                  </li>
                  <li>
                    <a>7</a>
                  </li>
                </ul>
              </div>
              <div className={styles.dateInfBox}>
                <div className={styles.dateBox}>
                  <div className={styles.dateTitleBox}>
                    <p className={styles.reserved}>Reserved</p>
                    <p className={styles.dateTitle}>Property Name</p>
                    <p className={styles.secondTitle}>Reserved</p>
                  </div>
                  <div className={styles.dateText}>
                    <p>18 April 2019</p>
                  </div>
                </div>

                <div className={styles.dateBox}>
                  <div className={styles.dateTitleBox}>
                    <p className={styles.reserved}>Reserved</p>
                    <p className={styles.dateTitle}>Property Name</p>
                    <p className={styles.secondTitle}>Reserved</p>
                  </div>
                  <div className={styles.dateText}>
                    <p>18 April 2019</p>
                  </div>
                </div>

                <div className={styles.dateBox}>
                  <div className={styles.dateTitleBox}>
                    <p className={styles.reserved}>Reserved</p>
                    <p className={styles.dateTitle}>Property Name</p>
                    <p className={styles.secondTitle}>Reserved</p>
                  </div>
                  <div className={styles.dateText}>
                    <p>18 April 2019</p>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.chart}>
              <div className={styles.whiteBoxChart}>
                <div className={styles.numberChart}>
                  <p className={styles.sold}>Sold</p>
                  <h1 className={styles.number}>
                    2412<sup className={styles.super}>Day</sup>
                    <sub className={styles.dollar}>$</sub>
                  </h1>
                </div>
                <div className={styles.timeChart}>
                  <div className={styles.timeBox}>
                    <p className={styles.price}>12.4 $</p>
                    <p className={styles.titlePrice}>year</p>
                  </div>
                  <div className={styles.timeBox}>
                    <p className={styles.price}>13 $</p>
                    <p className={styles.titlePrice}>today</p>
                  </div>
                </div>
              </div>
              <div className={styles.whiteBoxChart}>
                <div className={styles.numberChartBlue}>
                  <p className={styles.sold}>Reserved</p>
                  <h1 className={styles.number}>
                    89<sup className={styles.super}>Day</sup>
                    <sub className={styles.dollar}>$</sub>
                  </h1>
                </div>
                <div className={styles.timeChart}>
                  <div className={styles.timeBox}>
                    <p className={styles.priceBlue}>12.4 $</p>
                    <p className={styles.titlePrice}>year</p>
                  </div>
                  <div className={styles.timeBox}>
                    <p className={styles.priceBlue}>13 $</p>
                    <p className={styles.titlePrice}>today</p>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <section className={styles.chat}>
            <div className={styles.contact}>
              <div className={styles.newMessage}>
                <h1>chat</h1>
                <div className={styles.titleNew} />
              </div>
            </div>
            <div className={styles.message} />
          </section>
        </div>
        <div className={styles.whiteBox} />
      </div>
    </article>
  );
}
